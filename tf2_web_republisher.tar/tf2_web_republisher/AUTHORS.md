Original Authors
----------------

 * [Julius Kammerl](http://www.kammerl.de) (jkammerl@willowgarage.com)

Contributors
------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * [William Woodall](http://wjwwood.github.com) (wjwwood@gmail.com)
